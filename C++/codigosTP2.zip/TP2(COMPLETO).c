#include <stdio.h>

/*prototipos del programa*/
void iniciarProceso();
void leerRegistro();
void cargarContadoresEdif();
void generarCargarMostrarVector();
void deptosCorrientes();
void plurifamChaco();
float porcentajeEdifMisiones(int contEdifMisiones,int contEdifTotal);
void mostrarPorcentaje(float porcentaje);
void finalizarProceso();


 /* Declara un tipo de dato registro */
typedef struct{
int dni;
char AyN [30];
int codEdif;
char codProv;
float precio;

}tr_trabajos;

tr_trabajos vr_trabajos;
FILE * vf_trabajos;

int conCod01 = 0, conCod02 = 0, conCod03 = 0, conCod04 = 0, conCod05 = 0, conCod06 = 0, recaudadoChaco = 0, contEdifMisiones = 0, contEdifTotal = 0;
float porcentaje;

int main(){
	
	iniciarProceso();

	while(!feof(vf_trabajos)){
		
		leerRegistro();
		cargarContadoresEdif();
		deptosCorrientes();
		plurifamChaco();
}

	generarCargarMostrarVector();
	porcentajeEdifMisiones(contEdifMisiones,contEdifTotal);
	mostrarPorcentaje(porcentaje);
	finalizarProceso();
	
	return 0;
}

/* Abre archivo nuevo para grabar */
void iniciarProceso(){
	
	vf_trabajos = fopen("construNEA.dat", "rb"); 
	leerRegistro();	
}

/*grava los datos de los clientes en el archivo*/
void leerRegistro(){
	
	fread(&vr_trabajos, sizeof(tr_trabajos), 1, vf_trabajos); 
}

void cargarContadoresEdif(){
	
	if(vr_trabajos.codEdif == 01){
		conCod01 ++;
	}
	if(vr_trabajos.codEdif == 02){
		conCod02 ++;
	}
	if(vr_trabajos.codEdif == 03){
		conCod03 ++;
	}
	if(vr_trabajos.codEdif == 04){
		conCod04 ++;
	}
	if(vr_trabajos.codEdif == 05){
		conCod05 ++;
	}
	if(vr_trabajos.codEdif == 06){
		conCod06 ++;
	}
}

void generarCargarMostrarVector(){
	
	int vectorCodEdif [6];
	
	vectorCodEdif [0] = conCod01;
	vectorCodEdif [1] = conCod02;
	vectorCodEdif [2] = conCod03;
	vectorCodEdif [3] = conCod04;
	vectorCodEdif [4] = conCod05;
	vectorCodEdif [5] = conCod06;
		
	printf("\nCantidad de  edificaciones de codigo 01: %d",vectorCodEdif [0]);
	printf("\nCantidad de  edificaciones de codigo 02: %d",vectorCodEdif [1]);
	printf("\nCantidad de  edificaciones de codigo 03: %d",vectorCodEdif [2]);
	printf("\nCantidad de  edificaciones de codigo 04: %d",vectorCodEdif [3]);
	printf("\nCantidad de  edificaciones de codigo 05: %d",vectorCodEdif [4]);
	printf("\nCantidad de  edificaciones de codigo 06: %d",vectorCodEdif [5]);
	
	int i = 0;
	int menor = 7;
	
	for(i=0; i<6; i++){
		
		if(menor > vectorCodEdif[i]){
			
			 menor=vectorCodEdif[i];
		}
		
	}
	
	printf("\n\nEn la lista de abajo se muestra la o las edificaciones con menor cantidad de edificaiones: ");
	
	if(vectorCodEdif [0] == menor){
		printf("\n\tCodigo 01: %d",vectorCodEdif [0]);	
	}
	if(vectorCodEdif [1] == menor){
		printf("\n\tCodigo 02: %d",vectorCodEdif [1]);	
	}
	if(vectorCodEdif [2] == menor){
		printf("\n\tCodigo 03: %d",vectorCodEdif [2]);	
	}
	if(vectorCodEdif [3] == menor){
		printf("\n\tCodigo 04: %d",vectorCodEdif [3]);	
	}
	if(vectorCodEdif [4] == menor){
		printf("\n\tCodigo 05: %d",vectorCodEdif [4]);	
	}
	if(vectorCodEdif [5] == menor){
		printf("\n\tCodigo 06: %d",vectorCodEdif [5]);	
	}
	
	
}

void deptosCorrientes(){
	
	if(vr_trabajos.codEdif == 03 && vr_trabajos.codProv == 'a' || 'A'){
		
		printf("\nConstrucciones de departaentos en Corrientes...\n\tDNI: %i \n\tNombre: %s \n\tPrecio: %f \n\n",vr_trabajos.dni,vr_trabajos.AyN,vr_trabajos.precio);
		
	}
}

void plurifamChaco(){
	
	if(vr_trabajos.codEdif == 02 && vr_trabajos.codProv == 'b'|| 'B'){
		recaudadoChaco = recaudadoChaco + vr_trabajos.precio;
		
	}
}

float porcentajeEdifMisiones(int contMisiones, int contTotal){
	
	porcentaje = contMisiones * 100 / contTotal;
	return porcentaje;
}

void mostrarPorcentaje(float porcen){
	printf("\nPorcentaje de las construcciones en misiones: %f",porcen);
}

/*cierra el archivo*/
void finalizarProceso(){
fclose(vf_trabajos);
}
